#define N 10
#include<stdbool.h>

void NEW_INPUT();
bool Exists_PATH(int i , int j);
int floydWarshall();